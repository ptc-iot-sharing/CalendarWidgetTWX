export const x = () => {
  return 'bar';   
};

